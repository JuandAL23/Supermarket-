package demosupermercado;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Admin extends UsuarioBase {

    private static List<Producto> productos = new ArrayList<>();  // Lista de productos

    public Admin(String nombre) {
        super(nombre);
       
        if (productos.isEmpty()) {
            productos.add(new Producto("Leche", 2.5));
            productos.add(new Producto("Pan", 1.0));
            productos.add(new Producto("Coca-Cola", 1.5));
            productos.add(new Producto("Jugo", 2.0));
            productos.add(new Producto("Galletas", 1.2));
            productos.add(new Producto("Arroz", 3.0));
            productos.add(new Producto("Frijoles", 2.8));
            productos.add(new Producto("Azúcar", 1.5));
            productos.add(new Producto("Harina", 1.8));
            productos.add(new Producto("Pasta", 1.3));
        }
    }

    public static List<Producto> getProductos() {
        return productos;
    }

    @Override

public void mostrarMenu() {
    Scanner scanner = new Scanner(System.in);

    while (true) {
        System.out.println("\nBienvenido, " + nombre + ". Menú para el Administrador.");
        System.out.println("\nLista de productos disponibles:");
        for (int i = 0; i < productos.size(); i++) {
            System.out.println((i + 1) + ". " + productos.get(i).getNombre() + " - $" + productos.get(i).getPrecio());
        }

        System.out.println("\nSeleccione una opción:");
        System.out.println("1. Ver historial de ventas");
        System.out.println("2. Cambiar precio de un producto");
        System.out.println("3. Cambiar nombre de un producto");
        System.out.println("4. Cerrar sesión");

        int opcion = scanner.nextInt();

        switch (opcion) {
            case 1: {
                // Mostrar historial de ventas
                if (VentasRegistradas.getVentas().isEmpty()) {
                    System.out.println("No hay ventas registradas.");
                } else {
                    System.out.println("Historial de ventas:");
                    for (Ventas venta : VentasRegistradas.getVentas()) {
                        System.out.println(venta);
                    }
                }
                break;
            }
            case 2: {
                System.out.println("Ingrese el número del producto cuyo precio desea cambiar:");
                int numProducto = scanner.nextInt();
                if (numProducto > 0 && numProducto <= productos.size()) {
                    Producto producto = productos.get(numProducto - 1);
                    System.out.println("El precio actual de " + producto.getNombre() + " es $" + producto.getPrecio());
                    System.out.print("Ingrese el nuevo precio para " + producto.getNombre() + ": ");
                    double nuevoPrecio = scanner.nextDouble();
                    producto.setPrecio(nuevoPrecio);
                    System.out.println("Nuevo precio de " + producto.getNombre() + " es $" + producto.getPrecio());
                } else {
                    System.out.println("Producto no encontrado.");
                }
                break;
            }
            case 3: {
                System.out.println("Ingrese el número del producto cuyo nombre desea cambiar:");
                int numProducto = scanner.nextInt();
                if (numProducto > 0 && numProducto <= productos.size()) {
                    Producto producto = productos.get(numProducto - 1);
                    System.out.println("El nombre actual de este producto es " + producto.getNombre());
                    System.out.print("Ingrese el nuevo nombre para " + producto.getNombre() + ": ");
                    scanner.nextLine(); // Consumir el salto de línea restante
                    String nuevoNombre = scanner.nextLine();
                    producto.setNombre(nuevoNombre);
                    System.out.println("Nuevo nombre de producto es " + producto.getNombre());
                } else {
                    System.out.println("Producto no encontrado.");
                }
                break;
            }
            case 4: {
                // Cerrar sesión
                System.out.println("Cerrando sesión...");
                return; // Termina la ejecución del método y regresa al punto de inicio
            }
            default: {
                System.out.println("Opción no válida.");
                break;
            }
        }
    }
   }
}