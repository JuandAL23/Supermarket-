package demosupermercado;

import java.util.List;

public class Ventas {

    private List<ItemCarrito> productos;
    private double total;

    public Ventas(List<ItemCarrito> productos, double total) {
        this.productos = productos;
        this.total = total;
        registrarVenta();
    }

    private void registrarVenta() {
        System.out.println("\nVenta registrada:");
        for (ItemCarrito item : productos) {
            System.out.println(item.getCantidad() + " x " + item.getProducto().getNombre() + " - $" + item.getProducto().getPrecio() + " cada uno");
        }
        System.out.println("Total de la venta: $" + total);
    }

    public List<ItemCarrito> getProductos() {
        return productos;
    }

    public double getTotal() {
        return total;
    }
}
