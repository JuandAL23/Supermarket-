package demosupermercado;

import java.util.Scanner;

public class DemoSupermercado {

    public static void main(String[] args) {
        InicioSesion inicioSesion = new InicioSesion();

        while (true) {
            Usuario usuario = inicioSesion.autenticarUsuario();  // Autenticar usuario

            if (usuario == null) {
                System.out.println("Credenciales incorrectas. Fin del programa.");
                return;
            }

            usuario.mostrarMenu();  // Ejecutar menú según el tipo de usuario

            System.out.println("¿Desea cerrar sesión? (s/n)");
            Scanner scanner = new Scanner(System.in);
            String respuesta = scanner.nextLine();
            if (respuesta.equalsIgnoreCase("s")) {
                continue;  // Volver a pedir login
            } else {
                break;  // Salir
            }
        }
    }
}
