package demosupermercado;

import java.util.List;
import java.util.Scanner;

public class Trabajador extends UsuarioBase {

    private Carrito carrito;

    public Trabajador(String nombre) {
        super(nombre);
        carrito = new Carrito();
    }

    @Override
    public void mostrarMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nBienvenido, " + nombre + ". Menú para el Trabajador.");

            List<Producto> productos = Admin.getProductos();
            System.out.println("\nLista de productos disponibles:");
            for (int i = 0; i < productos.size(); i++) {
                System.out.println((i + 1) + ". " + productos.get(i).getNombre() + " - $" + productos.get(i).getPrecio());
            }

            System.out.println("\nSeleccione una opción:");
            System.out.println("1. Agregar producto al carrito");
            System.out.println("2. Ver carrito y calcular total");
            System.out.println("3. Imprimir factura");
            System.out.println("4. Cerrar sesión");

            int opcion = scanner.nextInt();

            if (opcion == 4) {
                System.out.println("Cerrando sesión...");
                break;
            } else if (opcion == 1) {
                System.out.println("Ingrese el número del producto que desea agregar al carrito:");
                int numProducto = scanner.nextInt();
                if (numProducto > 0 && numProducto <= productos.size()) {
                    Producto productoSeleccionado = productos.get(numProducto - 1);
                    System.out.print("Ingrese la cantidad que desea comprar de " + productoSeleccionado.getNombre() + ": ");
                    int cantidad = scanner.nextInt();
                    carrito.agregarProducto(productoSeleccionado, cantidad);
                    System.out.println(cantidad + " unidades de " + productoSeleccionado.getNombre() + " agregadas al carrito.");
                } else {
                    System.out.println("Opción no válida.");
                }
            } else if (opcion == 2) {
                System.out.println("Total en el carrito: $" + carrito.calcularTotal());
            } else if (opcion == 3) {
                // Registrar la venta en el historial usando la lista de ItemCarrito
                new Ventas(carrito.getProductos(), carrito.calcularTotal());

                // Imprimir la factura
                carrito.imprimirFactura();
            } else {
                System.out.println("Opción no válida.");
            }
        }
    }
}
