
package demosupermercado;

import java.util.ArrayList;
import java.util.List;

public class VentasRegistradas {

    private static List<Ventas> ventas = new ArrayList<>();  
    
    public static List<Ventas> getVentas() {
        return ventas;
    }

    
    public static void agregarVenta(Ventas venta) {
        ventas.add(venta);
    }

}
