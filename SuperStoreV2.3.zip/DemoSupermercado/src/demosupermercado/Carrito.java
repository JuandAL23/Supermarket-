package demosupermercado;

import java.util.ArrayList;
import java.util.List;

public class Carrito {

    private List<ItemCarrito> productos;

    public Carrito() {
        productos = new ArrayList<>();
    }

    // Método para agregar productos al carrito con su cantidad
    public void agregarProducto(Producto producto, int cantidad) {
        // Buscar si el producto ya está en el carrito
        boolean productoExistente = false;

        for (ItemCarrito item : productos) {
            if (item.getProducto().equals(producto)) {
                item.setCantidad(item.getCantidad() + cantidad); // Si ya existe, sumamos la cantidad
                productoExistente = true;
                break;
            }
        }

        if (!productoExistente) {
            productos.add(new ItemCarrito(producto, cantidad)); // Si no existe, lo agregamos
        }
    }

    // Método para calcular el total del carrito teniendo en cuenta las cantidades
    public double calcularTotal() {
        double total = 0;
        for (ItemCarrito item : productos) {
            total += item.getProducto().getPrecio() * item.getCantidad();
        }
        return total;
    }

    // Imprimir la factura con los productos en el carrito
    public void imprimirFactura() {
        System.out.println("\nFactura:");
        for (ItemCarrito item : productos) {
            System.out.println(item.getCantidad() + " x " + item.getProducto().getNombre() + " - $" + item.getProducto().getPrecio() + " cada uno");
        }
        System.out.println("\nTotal a pagar: $" + calcularTotal());
    }

    // Obtener la lista de productos en el carrito
    public List<ItemCarrito> getProductos() {
        return productos;
    }

    // Limpiar el carrito después de una venta
    public void limpiarCarrito() {
        productos.clear();
    }
}

// Clase auxiliar para almacenar un producto con su cantidad
class ItemCarrito {

    private Producto producto;
    private int cantidad;

    public ItemCarrito(Producto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
    }

    public Producto getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
