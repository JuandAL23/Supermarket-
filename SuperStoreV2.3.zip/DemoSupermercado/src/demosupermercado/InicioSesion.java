
package demosupermercado;

import java.util.Scanner;

public class InicioSesion {

    private final String adminUser = "admin";
    private final String adminPass = "admin123";
    private final String workerUser = "worker";
    private final String workerPass = "worker123";

    public Usuario autenticarUsuario() {
        Scanner scanner = new Scanner(System.in); // Corregido el error en System.in

        System.out.println("Inicio de Sesión:");
        System.out.print("Usuario: ");
        String usuario = scanner.nextLine();
        System.out.print("Contraseña: ");
        String contraseña = scanner.nextLine();

        if (usuario.equals(adminUser) && contraseña.equals(adminPass)) {
            return new Admin(usuario);  // Devuelve una instancia de Admin si las credenciales son correctas
        } else if (usuario.equals(workerUser) && contraseña.equals(workerPass)) {
            return new Trabajador(usuario);  // Devuelve una instancia de Trabajador si las credenciales son correctas
        } else {
            return null;  // Si las credenciales no coinciden, retorna null
        }
    }
}
