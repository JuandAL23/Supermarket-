package demosupermercado;

public abstract class UsuarioBase implements Usuario {
    protected String nombre;

    public UsuarioBase(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public abstract void mostrarMenu();
}
