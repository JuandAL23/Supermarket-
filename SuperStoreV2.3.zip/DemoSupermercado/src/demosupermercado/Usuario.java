package demosupermercado;

public interface Usuario {
    void mostrarMenu();
}
